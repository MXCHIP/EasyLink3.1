package com.easylink.android;

public interface ICallBack {
        public void onIpCb(String ip);
        public void onMacCb(String mac);
}
