/** Automatically generated file. DO NOT MODIFY */
package com.mxchip.ftc_service;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}