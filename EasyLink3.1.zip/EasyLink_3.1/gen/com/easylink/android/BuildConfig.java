/** Automatically generated file. DO NOT MODIFY */
package com.easylink.android;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}